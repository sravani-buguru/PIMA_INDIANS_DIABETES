```python
import pandas as pd
filename = 'pima-indians-diabetes.csv'
col_names = ['preg', 'plas', 'pres', 'skin', 'test', 'mass', 'pedi', 'age',
'class']
data = pd.read_csv(filename, names = col_names)
print("File loaded successfully")
```

    File loaded successfully
    


```python
print(data.head(20))                       
```

        preg  plas  pres  skin  test  mass   pedi  age  class
    0      6   148    72    35     0  33.6  0.627   50      1
    1      1    85    66    29     0  26.6  0.351   31      0
    2      8   183    64     0     0  23.3  0.672   32      1
    3      1    89    66    23    94  28.1  0.167   21      0
    4      0   137    40    35   168  43.1  2.288   33      1
    5      5   116    74     0     0  25.6  0.201   30      0
    6      3    78    50    32    88  31.0  0.248   26      1
    7     10   115     0     0     0  35.3  0.134   29      0
    8      2   197    70    45   543  30.5  0.158   53      1
    9      8   125    96     0     0   0.0  0.232   54      1
    10     4   110    92     0     0  37.6  0.191   30      0
    11    10   168    74     0     0  38.0  0.537   34      1
    12    10   139    80     0     0  27.1  1.441   57      0
    13     1   189    60    23   846  30.1  0.398   59      1
    14     5   166    72    19   175  25.8  0.587   51      1
    15     7   100     0     0     0  30.0  0.484   32      1
    16     0   118    84    47   230  45.8  0.551   31      1
    17     7   107    74     0     0  29.6  0.254   31      1
    18     1   103    30    38    83  43.3  0.183   33      0
    19     1   115    70    30    96  34.6  0.529   32      1
    


```python
print(data.shape)                    #shape method                                          
```

    (768, 9)
    


```python
types=data.dtypes
print(types)                          #data types of attributes in data
```

    preg       int64
    plas       int64
    pres       int64
    skin       int64
    test       int64
    mass     float64
    pedi     float64
    age        int64
    class      int64
    dtype: object
    


```python
description=data.describe()
print(description)                      # describe method
```

                 preg        plas        pres        skin        test        mass  \
    count  768.000000  768.000000  768.000000  768.000000  768.000000  768.000000   
    mean     3.845052  120.894531   69.105469   20.536458   79.799479   31.992578   
    std      3.369578   31.972618   19.355807   15.952218  115.244002    7.884160   
    min      0.000000    0.000000    0.000000    0.000000    0.000000    0.000000   
    25%      1.000000   99.000000   62.000000    0.000000    0.000000   27.300000   
    50%      3.000000  117.000000   72.000000   23.000000   30.500000   32.000000   
    75%      6.000000  140.250000   80.000000   32.000000  127.250000   36.600000   
    max     17.000000  199.000000  122.000000   99.000000  846.000000   67.100000   
    
                 pedi         age       class  
    count  768.000000  768.000000  768.000000  
    mean     0.471876   33.240885    0.348958  
    std      0.331329   11.760232    0.476951  
    min      0.078000   21.000000    0.000000  
    25%      0.243750   24.000000    0.000000  
    50%      0.372500   29.000000    0.000000  
    75%      0.626250   41.000000    1.000000  
    max      2.420000   81.000000    1.000000  
    


```python
class_counts=data.groupby('class').size()
print(class_counts)                                                  #groupby method
```

    class
    0    500
    1    268
    dtype: int64
    


```python
correlations=data.corr(method='pearson')                            # finding correalations between attributes
print(correlations)
```

               preg      plas      pres      skin      test      mass      pedi  \
    preg   1.000000  0.129459  0.141282 -0.081672 -0.073535  0.017683 -0.033523   
    plas   0.129459  1.000000  0.152590  0.057328  0.331357  0.221071  0.137337   
    pres   0.141282  0.152590  1.000000  0.207371  0.088933  0.281805  0.041265   
    skin  -0.081672  0.057328  0.207371  1.000000  0.436783  0.392573  0.183928   
    test  -0.073535  0.331357  0.088933  0.436783  1.000000  0.197859  0.185071   
    mass   0.017683  0.221071  0.281805  0.392573  0.197859  1.000000  0.140647   
    pedi  -0.033523  0.137337  0.041265  0.183928  0.185071  0.140647  1.000000   
    age    0.544341  0.263514  0.239528 -0.113970 -0.042163  0.036242  0.033561   
    class  0.221898  0.466581  0.065068  0.074752  0.130548  0.292695  0.173844   
    
                age     class  
    preg   0.544341  0.221898  
    plas   0.263514  0.466581  
    pres   0.239528  0.065068  
    skin  -0.113970  0.074752  
    test  -0.042163  0.130548  
    mass   0.036242  0.292695  
    pedi   0.033561  0.173844  
    age    1.000000  0.238356  
    class  0.238356  1.000000  
    


```python
skew=data.skew()
print(skew)                                        #Skew of Univariate Distributions
```

    preg     0.901674
    plas     0.173754
    pres    -1.843608
    skin     0.109372
    test     2.272251
    mass    -0.428982
    pedi     1.919911
    age      1.129597
    class    0.635017
    dtype: float64
    

# Data using visuliazition

# Histogram


```python
from matplotlib import pyplot
data.hist()
pyplot.show
```




    <function matplotlib.pyplot.show(close=None, block=None)>




    
![png](output_10_1.png)
    


data.plot(
kind = 'box',
subplots = True,
layout = (3,3),
sharex = False,
sharey = False
)
pyplot.show()

# Box & Whisker plot


```python
data.plot(
kind = 'box',
subplots = True,
layout = (3,3),
sharex = False,
sharey = False
)
pyplot.show()
```


    
![png](output_13_0.png)
    


# Multivariable plots




```python
import numpy
```


```python
correlations = data.corr()
fig = pyplot.figure()
ax = fig.add_subplot(111)
cax = ax.matshow(correlations, vmin=-1, vmax=1)
fig.colorbar(cax)
ticks = numpy.arange(0,9,1)
ax.set_xticks(ticks)
ax.set_yticks(ticks)
ax.set_xticklabels(col_names)
ax.set_yticklabels(col_names)
pyplot.show()
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    Cell In[24], line 6
          4 cax = ax.matshow(correlations, vmin=-1, vmax=1)
          5 fig.colorbar(cax)
    ----> 6 ticks = numpy.arange(0,9,1)
          7 ax.set_xticks(ticks)
          8 ax.set_yticks(ticks)
    

    NameError: name 'numpy' is not defined



    
![png](output_16_1.png)
    


# Scatter Plot Matrix


```python
from pandas.plotting import scatter_matrix
scatter_matrix(data)
pyplot.show()
```


    
![png](output_18_0.png)
    


# Rescale the data 


```python
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from numpy import set_printoptions

filename = 'pima-indians-diabetes.csv'
col_names = ['preg', 'plas', 'pres', 'skin', 'test', 'mass', 'pedi', 'age',
'class']

dataframe = pd.read_csv(filename, names = col_names)

array = dataframe.values
X = array[:,0:8]
Y = array[:,8]
scaler = MinMaxScaler(feature_range = (0, 1))
rescaledX = scaler.fit_transform(X)
set_printoptions(precision = 3)
print(rescaledX[0:5,:])
```

    [[0.353 0.744 0.59  0.354 0.    0.501 0.234 0.483]
     [0.059 0.427 0.541 0.293 0.    0.396 0.117 0.167]
     [0.471 0.92  0.525 0.    0.    0.347 0.254 0.183]
     [0.059 0.447 0.541 0.232 0.111 0.419 0.038 0.   ]
     [0.    0.688 0.328 0.354 0.199 0.642 0.944 0.2  ]]
    


```python
from sklearn.preprocessing import StandardScaler
from numpy import set_printoptions
dataframe = pd.read_csv(filename, names = col_names)
array = dataframe.values
X = array[:,0:8]
Y = array[:,8]
scaler = StandardScaler().fit(X)
rescaledX = scaler.transform(X)
set_printoptions(precision = 3)
print(rescaledX[0:5,:])
```

    [[ 0.64   0.848  0.15   0.907 -0.693  0.204  0.468  1.426]
     [-0.845 -1.123 -0.161  0.531 -0.693 -0.684 -0.365 -0.191]
     [ 1.234  1.944 -0.264 -1.288 -0.693 -1.103  0.604 -0.106]
     [-0.845 -0.998 -0.161  0.155  0.123 -0.494 -0.921 -1.042]
     [-1.142  0.504 -1.505  0.907  0.766  1.41   5.485 -0.02 ]]
    


```python
from sklearn.preprocessing import Normalizer
dataframe = pd.read_csv(filename, names = col_names)
array = dataframe.values
X = array[:,0:8]
Y = array[:,8]
scaler = Normalizer().fit(X)
normalizedX = scaler.transform(X)
set_printoptions(precision=3)
print(normalizedX[0:5,:])
```

    [[0.034 0.828 0.403 0.196 0.    0.188 0.004 0.28 ]
     [0.008 0.716 0.556 0.244 0.    0.224 0.003 0.261]
     [0.04  0.924 0.323 0.    0.    0.118 0.003 0.162]
     [0.007 0.588 0.436 0.152 0.622 0.186 0.001 0.139]
     [0.    0.596 0.174 0.152 0.731 0.188 0.01  0.144]]
    

# Binarize data


```python
from sklearn.preprocessing import Binarizer
from numpy import set_printoptions
dataframe = pd.read_csv(filename, names = col_names)
array = dataframe.values
                                                               # separate array into input and output components
X = array[:, 0:8]
Y = array[:, 8]
binarizer = Binarizer(threshold = 0.0).fit(X)
binaryX = binarizer.transform(X)
                                                              # summarize transformed data
set_printoptions(precision=3)
print(binaryX[0:5,:])
```

    [[1. 1. 1. 1. 0. 1. 1. 1.]
     [1. 1. 1. 1. 0. 1. 1. 1.]
     [1. 1. 1. 0. 0. 1. 1. 1.]
     [1. 1. 1. 1. 1. 1. 1. 1.]
     [0. 1. 1. 1. 1. 1. 1. 1.]]
    

# Univariable selection


```python
from numpy import set_printoptions
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2
dataframe = pd.read_csv(filename, names = col_names)
array = dataframe.values
X = array[:,0:8]
Y = array[:,8]
test = SelectKBest(score_func = chi2, k = 4)
fit = test.fit(X, Y)
                                                                  # summarize scores
set_printoptions(precision = 3)
print(fit.scores_)
features = fit.transform(X)
                                                                # summarize selected features
print(features[0:5,:])
```

    [ 111.52  1411.887   17.605   53.108 2175.565  127.669    5.393  181.304]
    [[148.    0.   33.6  50. ]
     [ 85.    0.   26.6  31. ]
     [183.    0.   23.3  32. ]
     [ 89.   94.   28.1  21. ]
     [137.  168.   43.1  33. ]]
    


```python
from sklearn.ensemble import ExtraTreesClassifier
dataframe = pd.read_csv(filename, names = col_names)
array = dataframe.values
X = array[:, 0:8]
Y = array[:, 8]
model = ExtraTreesClassifier()
model.fit(X, Y)
print(model.feature_importances_)
```

    [0.108 0.239 0.097 0.08  0.077 0.138 0.118 0.143]
    

# Training and Testing Datasert 


```python
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
dataframe = pd.read_csv(filename, names = col_names)
array = dataframe.values
X = array[:, 0:8]
Y = array[:, 8]
test_size = 0.33
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size =
test_size)
model = LogisticRegression(solver = 'lbfgs', max_iter = 3000)
model.fit(X_train, Y_train)
result = model.score(X_test, Y_test)
print("Accuracy:", result*100.0)
```

    Accuracy: 77.55905511811024
    

#  K fold cross validation


```python
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
from sklearn.linear_model import LogisticRegression

dataframe = pd.read_csv(filename, names = col_names)
array = dataframe.values
X = array[:, 0:8]
Y = array[:, 8]
num_folds = 10
kfold = KFold(n_splits = num_folds)
model = LogisticRegression(solver = 'lbfgs', max_iter = 3000)
results = cross_val_score(model, X, Y, cv = kfold)
print("Accuracy:", results.mean()*100.0)
```

    Accuracy: 77.60423786739577
    


```python
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
from sklearn.linear_model import LogisticRegression

dataframe = pd.read_csv(filename, names = col_names)
array = dataframe.values
X = array[:, 0:8]
Y = array[:, 8]
kfold = KFold(n_splits = 10)
model = LogisticRegression(solver = 'lbfgs', max_iter = 3000)
scoring = 'accuracy'
results = cross_val_score(model, X, Y, cv = kfold, scoring = scoring)
print("Accuracy: ", results.mean())
```

    Accuracy:  0.7760423786739576
    


```python
dataframe = pd.read_csv(filename, names = col_names)
array = dataframe.values
X = array[:, 0:8]
Y = array[:, 8]
kfold = KFold(n_splits = 10)
model = LogisticRegression(solver = 'lbfgs', max_iter = 3000)
scoring = 'roc_auc'
results = cross_val_score(model, X, Y, cv = kfold, scoring = scoring)
print("AUC:", results.mean()*100)
```

    AUC: 82.80277116334987
    


```python
import pandas as pd
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
from sklearn.linear_model import LogisticRegression
filename = 'pima-indians-diabetes.csv'
col_names = ['preg', 'plas', 'pres', 'skin', 'test', 'mass', 'pedi', 'age',
'class']
dataframe = pd.read_csv(filename, names = col_names)
array = dataframe.values
X = array[:, 0:8]
Y = array[:, 8]
kfold = KFold(n_splits = 10)
model = LogisticRegression(solver = 'lbfgs', max_iter = 3000)
scoring = 'accuracy'
results = cross_val_score(model, X, Y, cv = kfold, scoring = scoring)
print("Accuracy: ", results.mean())
```

    Accuracy:  0.7760423786739576
    


```python
import pandas as pd
from matplotlib import pyplot
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
filename = 'pima-indians-diabetes.csv'
col_names = ['preg', 'plas', 'pres', 'skin', 'test', 'mass', 'pedi', 'age',
'class']
dataframe = pd.read_csv(filename, names = col_names)
array = dataframe.values
X = array[:, 0:8]
y = array[:, 8]


models = []
models.append(('LR', LogisticRegression(solver = 'lbfgs', max_iter
= 3000)))
models.append(('LDA', LinearDiscriminantAnalysis()))
models.append(('KNN', KNeighborsClassifier()))
models.append(('CART', DecisionTreeClassifier()))
models.append(('NB', GaussianNB()))
models.append(('SVM', SVC()))
results = []
names = []
scoring = 'accuracy'
for name, model in models:
    kfold = KFold(n_splits = 10)
    cv_results = cross_val_score( model,X,y,cv = kfold,scoring = scoring)
results.append(cv_results)
names.append(name)
msg = (name, cv_results.mean(),cv_results.std())
print(msg)
fig = pyplot.figure()
fig.suptitle('Algorithm Comparison')
ax = fig.add_subplot(111)
pyplot.boxplot(results)
ax.set_xticklabels(names)
pyplot.show()
```

    ('SVM', 0.7604237867395763, 0.05293077027238117)
    


    
![png](output_35_1.png)
    

